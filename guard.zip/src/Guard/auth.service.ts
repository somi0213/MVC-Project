import { HttpClient } from "@angular/common/http";

export class AuthService {

    private registerUrl = "http://localhost:4200/register";
      private loginUrl = "http://localhost:4200/user";

      constructor(private http: HttpClient){}

    //   registerUser(register){
    //       return this.http.post<any>(this.registerUrl, register)
    //   }

    //   loginUser(user){
    //        return this.http.post<any>(this.loginUrl, user)
    //   }

    //   loggedIn(){
    //       return !!localStorage.getItem('token')
    //   }
     
     isLoggedIn:boolean;

     loggedIn(){
         return this.isLoggedIn;
     }

}