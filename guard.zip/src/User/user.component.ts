import { User } from './user';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import { RegisterComponent } from "src/register/register.component";
import { AuthService } from "src/Guard/auth.service";
import { RegisterService } from "src/register/register.service";

@Component({
    selector:'user-app',
    templateUrl:'./user.component.html'
})
export class UserComponent implements OnInit{
    constructor(private route:ActivatedRoute, private router: Router , private registerService : RegisterService ,  private auth : AuthService ) {
   
}
    ngOnInit(): void {  
    }


    register = new User();

    login(){

        this.registerService.enrollUser(this.register).subscribe(
        data =>{
            if( data == true){
                 console.log('Success  !!',data)
                    this.auth.isLoggedIn = true;
            }else{
                 console.log('Success  !!',data)
                    this.auth.isLoggedIn = false;
            }
           
        },
    )
    }

onBack() : void{
    this.router.navigate(['/home']);
}


}