export class User{
constructor(
public username ='',
public password ='',
)
{}


}
    
