import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './../Home/Home.component';
// import {TravelComponent} from './../Travel/Travel.component';
import { UserComponent } from './../User/user.component';
import {FeaturesComponent} from './../Features/features.component';
import {ContactComponent} from './../contact/contact.component';
import { ErrorComponent } from './../error/error.component';
import { RegisterComponent } from '../register/register.component';
 import {BookingComponent } from '../booking/booking.component';
 import { ViewComponent } from "src/view/view.component";
 import { AuthGuard } from "src/Guard/auth.guard";
//import {PlacesComponent} from './../Places/places.component';

const routes: Routes = [

  { path:'home', component:HomeComponent},
 { path:'features', component:FeaturesComponent , canActivate:[AuthGuard]},
 { path:'user', component:UserComponent},
 { path:'contact', component:ContactComponent},
 { path:'register', component:RegisterComponent},
   { path:'booking', component:BookingComponent},
     { path:'booking', component:BookingComponent},
//{ path:'**',component:ErrorComponent },

{path:'view', component:ViewComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

