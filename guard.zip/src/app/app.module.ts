import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { UserComponent } from './../User/user.component';
import { HomeComponent } from './../Home/Home.component';
import { FeaturesComponent } from './../Features/features.component';
import { ContactComponent } from './../contact/contact.component';
import { ErrorComponent } from './../error/error.component';
import { RegisterComponent } from './../register/register.component';
import { HttpClientModule } from "@angular/common/http";
import { BookingComponent } from "../booking/booking.component";
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ViewComponent } from "src/view/view.component";
import { AuthGuard } from "src/Guard/auth.guard";
import { AuthService } from "src/Guard/auth.service";
import { RegisterService } from "src/register/register.service";
//import { pageGaurdComponent } from "src/Gaurd/pageGaurd.component";
// import { pageGuardComponent } from "src/Guard/pageGuard.component";


@NgModule({
  declarations: [
    AppComponent, 
    UserComponent,
    HomeComponent,
    FeaturesComponent,
    ContactComponent,
    ErrorComponent,
    RegisterComponent,
    BookingComponent,
    ViewComponent,
    
    //pageGaurdComponent
    // pageGuardComponent
  ],
  imports: [
    BrowserModule,
   
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
   
  ReactiveFormsModule,
    Ng2SearchPipeModule
 
  ],
  providers: [AuthGuard , AuthService , RegisterService],
  bootstrap: [AppComponent]
})

export class AppModule { }
