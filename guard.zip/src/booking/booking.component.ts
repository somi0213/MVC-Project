

import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { BookingService } from "src/booking/booking.service";
import { Booking } from "src/booking/booking";
import { NgForm } from "@angular/forms/forms";

@Component({
    selector:'booking',
    templateUrl:'booking2.component.html'
})
export class BookingComponent implements OnInit{
   ngOnInit(): void {
   }
        constructor(private route : ActivatedRoute , private router : Router , private http:HttpClient ,
                         private bookingService: BookingService){
       
    };


      booking = new Booking();

      onBack() : void{
        this.router.navigate(['/home'])
    }

      save(userForm:NgForm){

        console.log("Saved Form" );

        this.bookingService.enroll(this.booking).subscribe(
            data => console.log('Success !!' , data),
        )

        this.router.navigate(['/view']);
    }

}

