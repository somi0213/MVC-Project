import { Register } from './register';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import { RegisterService } from "src/register/register.service";
import { AuthService } from "src/Guard/auth.service";

@Component({
    selector:'regsiter-app',
    templateUrl:'./register.component.html'
})
export class RegisterComponent implements OnInit{
    constructor(private route:ActivatedRoute, private router: Router, private registerService: RegisterService , private auth : AuthService) {
   
    
};
    ngOnInit(): void {
        
    }
 
 
 
    register = new Register();





// save(registerForm:NgForm){
// console.log(registerForm.form);
// //console.log('Saved data ' + registerForm.value) ;
// console.log("Saved Form" );
//     this.registerService.enroll(this.register).subscribe(
//         data =>{
//             if( data == true){
//                  console.log('Success  !!',data)
//                     this.auth.isLoggedIn = true;
//             }else{
//                  console.log('Success  !!',data)
//                     this.auth.isLoggedIn = false;
//             }
           
//         },
//     )
// }

onBack() : void{
    this.router.navigate(['/home']);
}

}
//  save(userForm:NgForm){

//         console.log("Saved Form" );

//         this.bookingService.enroll(this.booking).subscribe(
//             data => console.log('Success !!' , data),
//         )

//         this.router.navigate(['/view']);
//     }