import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Register } from "src/register/register";
import { User } from "src/User/user";

@Injectable({
    providedIn : 'root'
})


export class RegisterService {

    constructor(private http : HttpClient){
    }
    url='http://localhost:9080/register';

    enroll(register : Register){ 

        console.log("register service called");
        return this.http.post("http://localhost:9080/register", register);
    }

    enrollUser(register:User){
        console.log(" user service called");
        return this.http.post("http://localhost:9080/user", register);
    }
    

}

  
